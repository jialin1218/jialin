/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Page, SectionTitle } from "./components/Layout";
import { motion } from "motion/react";
import { 
  Check, 
  ArrowRight, 
  TrendingUp, 
  Clock, 
  Smartphone, 
  ShoppingBag, 
  Radar, 
  ShieldCheck, 
  Infinity,
  User,
  Map,
  Target,
  Zap,
  Globe
} from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell
} from "recharts";

const successRateData = [
  { name: '2025-06', value: 10 },
  { name: '07', value: 12 },
  { name: '08', value: 15 },
  { name: '09', value: 22 },
  { name: '10', value: 25 },
  { name: '11', value: 28 },
  { name: '12', value: 30 },
];

const prepCycleData = [
  { stage: '初创期', weeks: 4 },
  { stage: '优化期', weeks: 2 },
  { stage: '高效期', weeks: 1 },
];

const adSpendData = [
  { category: '手机', value: 5, target: 20 },
  { category: '女装', value: 8, target: 25 },
];

export default function App() {
  return (
    <main className="snap-y snap-mandatory overflow-y-auto h-screen scroll-smooth">
      
      {/* PAGE 1: HERO */}
      <Page id="hero" className="relative flex-col items-center justify-center text-center snap-start">
        <motion.div
           initial={{ opacity: 0, scale: 0.9 }}
           animate={{ opacity: 1, scale: 1 }}
           transition={{ duration: 1 }}
           className="space-y-6"
        >
          <h1 className="text-8xl md:text-[12rem] font-serif italic font-bold text-neutral-900 tracking-tighter opacity-10">
            Portfolio
          </h1>
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
             <motion.h1 
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3 }}
                className="text-6xl md:text-9xl font-display font-bold tracking-tight"
             >
               Portfolio
             </motion.h1>
             <motion.p 
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="text-xl md:text-2xl font-medium text-neutral-500 mt-4 tracking-[0.3em] uppercase"
             >
               海外内容增长作品集
             </motion.p>
          </div>
        </motion.div>
        <motion.div 
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute bottom-12 left-1/2 -translate-x-1/2 text-neutral-300"
        >
          <ArrowRight className="rotate-90 w-6 h-6" />
        </motion.div>
      </Page>

      {/* PAGE 2: ABOUT ME */}
      <Page id="about" bgWhite className="snap-start">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <motion.div 
             initial={{ x: -50, opacity: 0 }}
             whileInView={{ x: 0, opacity: 1 }}
             viewport={{ once: true }}
             className="relative aspect-[3/4] rounded-2xl overflow-hidden bg-neutral-200 shadow-2xl"
          >
            <img 
              src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=1000&auto=format&fit=crop" 
              alt="Avatar"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-neutral-900/10 mix-blend-overlay"></div>
          </motion.div>
          <div className="space-y-12">
            <div>
              <SectionTitle title="About Me" subtitle="PROFILE" centered={false} />
              <h3 className="text-4xl font-bold mb-4">Jialin</h3>
              <p className="text-xl text-neutral-500 font-medium">3年+海外内容增长</p>
            </div>
            
            <div className="space-y-6">
              {[
                "深度市场洞察",
                "高效内容营销",
                "闭环变现能力",
                "全链路资源整合"
              ].map((item, i) => (
                <motion.div 
                  initial={{ x: 20, opacity: 0 }}
                  whileInView={{ x: 0, opacity: 1 }}
                  transition={{ delay: i * 0.1 }}
                  key={i} 
                  className="flex items-center gap-4 group"
                >
                  <div className="w-10 h-10 rounded-full bg-neutral-900 flex items-center justify-center text-white shrink-0 group-hover:scale-110 transition-transform">
                    <Check className="w-5 h-5" />
                  </div>
                  <span className="text-2xl font-semibold text-neutral-800">{item}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </Page>

      {/* PAGE 3: CONTENTS */}
      <Page id="contents" className="snap-start bg-neutral-900 text-white">
        <SectionTitle title="CONTENTS" subtitle="STRATEGY MAP" />
        <div className="relative mt-20">
          <div className="absolute top-1/2 left-0 w-full h-[2px] bg-neutral-800 hidden md:block"></div>
          <div className="grid md:grid-cols-3 gap-12 relative">
            {[
              { title: "市场洞察与商业化变现", desc: "Market Insight" },
              { title: "可复制爆款能力", desc: "Content Capability" },
              { title: "跨部门整合资源", desc: "Resource Integration" }
            ].map((item, i) => (
              <motion.div 
                key={i}
                initial={{ y: 30, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ delay: i * 0.2 }}
                className="relative flex flex-col items-center text-center group"
              >
                <div className="w-20 h-20 rounded-full bg-white text-neutral-900 flex items-center justify-center mb-8 relative z-10 group-hover:scale-110 transition-transform duration-500">
                  <Map className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-bold mb-3">{item.title}</h3>
                <p className="text-neutral-500 uppercase tracking-widest text-sm">{item.desc}</p>
                {i < 2 && (
                  <ArrowRight className="absolute -right-6 top-1/2 -translate-y-1/2 w-6 h-6 text-neutral-700 hidden md:block" />
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </Page>

      {/* PAGE 4: Temu Romania Market */}
      <Page id="temu" className="snap-start relative overflow-hidden" bgWhite>
        <div className="absolute inset-0 -z-10 bg-gradient-to-br from-blue-600 via-yellow-400 to-red-600 opacity-20 blur-[100px] scale-150"></div>
        <div className="absolute inset-0 -z-20 bg-amber-50/50"></div>
        
        <div className="relative z-10 text-center mb-20">
           <SectionTitle title="市场洞察与商业化变现" subtitle="CASE STUDY" />
           <p className="text-2xl font-display font-medium text-neutral-600 -mt-12">Temu 罗马尼亚市场</p>
        </div>

        <div className="grid grid-cols-1 gap-8 max-w-6xl mx-auto">
          {/* Header Row */}
          <div className="grid grid-cols-3 gap-6 mb-4 px-8 hidden md:grid">
            <div className="text-center font-display font-bold text-neutral-400 text-sm uppercase tracking-widest">Insight</div>
            <div className="text-center font-display font-bold text-neutral-400 text-sm uppercase tracking-widest">Action</div>
            <div className="text-center font-display font-bold text-neutral-400 text-sm uppercase tracking-widest">Impact</div>
          </div>

          {[
            {
              title: "女装货盘重构",
              insight: "捕捉本土民族风女装审美红利与品类搜索热度",
              action: "跨部门联动供应链/招商端，定向开款，精准填补站内供给空缺",
              impact: "沉淀高转本土女装视觉内容矩阵，创造$600,000+ GMV"
            },
            {
              title: "垂类增量挖掘",
              insight: "深度拆解本土国民休闲生活方式—“钓鱼文化”",
              action: "避开红海竞争的基础装备，主推高专业度、细分场景的专业钓鱼装备",
              impact: "爆品矩阵拉动类目增长，户外由当地边缘类目拉升至站内腰部类目"
            },
            {
              title: "原生创意破局",
              insight: "用户抗拒精致广告，偏好原生感、有趣内容",
              action: "抛弃传统棚拍，主导本地生活场景的短剧情拍摄",
              impact: "创意生命周期大幅延长，产出多条花费$300,000+的爆款视频"
            }
          ].map((item, i) => (
            <motion.div 
              key={i}
              initial={{ x: -20, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              transition={{ delay: i * 0.1 }}
              className="bg-white/40 backdrop-blur-md rounded-3xl p-8 border border-white/50 shadow-sm relative group"
            >
              <div className="absolute -left-4 top-1/2 -translate-y-1/2 bg-neutral-900 text-white text-xs px-4 py-1 rotate-[-90deg] font-bold rounded-full">
                {item.title}
              </div>
              <div className="grid md:grid-cols-3 gap-12 items-center">
                <div className="relative">
                  <p className="text-lg font-medium leading-relaxed">{item.insight}</p>
                  <ArrowRight className="absolute -right-8 top-1/2 -translate-y-1/2 w-6 h-6 text-neutral-300 hidden md:block" />
                </div>
                <div className="relative">
                  <p className="text-lg text-neutral-600 leading-relaxed font-light">{item.action}</p>
                  <ArrowRight className="absolute -right-8 top-1/2 -translate-y-1/2 w-6 h-6 text-neutral-300 hidden md:block" />
                </div>
                <div className="bg-neutral-900 text-white p-6 rounded-2xl">
                  <p className="text-lg font-bold">{item.impact}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </Page>

      {/* PAGE 5: OMTech USA Market */}
      <Page id="omtech" className="snap-start relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-gradient-to-br from-blue-900 via-white to-red-600 opacity-15 blur-[100px] scale-150"></div>
        <div className="absolute inset-0 -z-20 bg-neutral-50/80"></div>
        
        <div className="relative z-10 text-center mb-20">
           <SectionTitle title="市场洞察与商业化变现" subtitle="CASE STUDY" />
           <p className="text-2xl font-display font-medium text-neutral-600 -mt-12">OMTech 美国市场</p>
        </div>

        <div className="max-w-5xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="bg-white rounded-[40px] p-12 shadow-2xl border border-neutral-100"
          >
            <div className="flex flex-col md:flex-row gap-4 items-center justify-between mb-12 border-b border-neutral-100 pb-8">
              <h3 className="text-3xl font-display font-bold">高客单价科技设备的视觉心智重构</h3>
              <div className="flex items-center gap-2 bg-blue-50 text-blue-600 px-4 py-2 rounded-full text-sm font-bold uppercase tracking-tighter">
                <Smartphone className="w-4 h-4" />
                Visual Marketing
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-16 relative">
              <div className="space-y-6">
                <div className="w-12 h-12 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center font-bold">INSIGHT</div>
                <p className="text-lg leading-relaxed font-medium">
                  深度剖析北美创客的购买决策漏斗，发现面对几千美金的专业激光设备时，最大的转化阻力并非价格，而是“晦涩的技术参数带来的认知门槛”以及“缺乏本土使用场景的代入感”
                </p>
                <div className="absolute right-0 top-1/2 -translate-y-1/2 h-2/3 w-[1px] bg-neutral-100 hidden md:block"></div>
              </div>

              <div className="space-y-6 relative">
                <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center font-bold">ACTION</div>
                <p className="text-lg leading-relaxed text-neutral-600">
                  主导 Listing 视觉重构与 A+ 页面全面升级，将冰冷的机械硬指标“翻译”为直击痛点的场景化利益点。摒弃传统的参数罗列，创新性引入“切割厚度可视化”设计，并针对北美受众深度定制了“本土化车库工作坊场景渲染”，用视觉直接构建信任
                </p>
                <div className="absolute right-0 top-1/2 -translate-y-1/2 h-2/3 w-[1px] bg-neutral-100 hidden md:block"></div>
              </div>

              <div className="space-y-6">
                <div className="w-12 h-12 rounded-xl bg-neutral-900 text-white flex items-center justify-center font-bold">IMPACT</div>
                <p className="text-xl leading-relaxed font-bold text-neutral-900 italic">
                  "成功打破了高客单价专业设备的转化防线，将复杂的决策链路降至极简。核心 SKU 的页面转化率 (CVR) 得到显著拉升，直接驱动单品 GMV 实现阶梯式突破"
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </Page>

      {/* PAGE 6: Reproducible Explosive Creative */}
      <Page id="reproducible" bgWhite className="snap-start">
        <SectionTitle title="可复制爆款能力" subtitle="CAPABILITY" />
        
        <div className="grid lg:grid-cols-12 gap-12 mt-12">
          {/* Left Flowchart */}
          <div className="lg:col-span-4 space-y-8">
            <h4 className="text-2xl font-bold bg-neutral-100 p-4 rounded-xl inline-block">爆款方法论</h4>
            <div className="relative space-y-12 pl-10">
               <div className="absolute left-[19px] top-6 bottom-6 w-[2px] bg-neutral-200"></div>
               {[
                 { title: "目标用户精准定位", icon: <User className="w-5 h-5"/>, color: "bg-blue-500" },
                 { title: "对标竞对分析", icon: <Target className="w-5 h-5"/>, color: "bg-orange-500" },
                 { title: "选：搭建选品标签体系，迭代优质选品", icon: <ShoppingBag className="w-5 h-5"/>, color: "bg-green-500" },
                 { title: "拍：本土化内容创作-三段式爆款公式", icon: <Smartphone className="w-5 h-5"/>, color: "bg-purple-500" },
                 { title: "推：拆解素材链路数据，精准找到爆点", icon: <TrendingUp className="w-5 h-5"/>, color: "bg-red-500" }
               ].map((item, i) => (
                 <motion.div 
                    initial={{ x: -20, opacity: 0 }}
                    whileInView={{ x: 0, opacity: 1 }}
                    transition={{ delay: i * 0.1 }}
                    key={i} 
                    className="relative"
                 >
                   <div className={cn("absolute -left-10 top-0 w-10 h-10 rounded-xl flex items-center justify-center text-white z-10", item.color)}>
                     {item.icon}
                   </div>
                   <p className="text-xl font-medium pt-1">{item.title}</p>
                 </motion.div>
               ))}
            </div>
          </div>

          {/* Right Dashboard */}
          <div className="lg:col-span-8 bg-neutral-50 rounded-3xl p-8 border border-neutral-100 shadow-sm space-y-8">
             <div className="flex items-center justify-between">
                <h4 className="text-2xl font-bold">数据看板 (Data Dashboard)</h4>
                <div className="text-sm font-bold text-neutral-400">2025 Q3-Q4</div>
             </div>

             <div className="grid md:grid-cols-2 gap-8">
                {/* Graph 1: Success Rate */}
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-neutral-100">
                  <p className="text-sm font-bold text-neutral-400 mb-4 uppercase">爆款率增长趋势</p>
                  <div className="h-48">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={successRateData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} />
                        <XAxis dataKey="name" hide />
                        <YAxis hide />
                        <Tooltip 
                          contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                        />
                        <Line type="monotone" dataKey="value" stroke="#000" strokeWidth={3} dot={{ r: 4, fill: "#000" }} animationDuration={2000} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="flex justify-between items-baseline mt-2">
                    <span className="text-4xl font-display font-bold">30%</span>
                    <span className="text-green-500 font-bold flex items-center gap-1 text-sm">
                      <TrendingUp className="w-4 h-4" /> +200%
                    </span>
                  </div>
                </div>

                {/* Graph 2: Prep Cycle */}
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-neutral-100">
                  <p className="text-sm font-bold text-neutral-400 mb-4 uppercase">平均拍摄筹备周期</p>
                  <div className="h-48">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={prepCycleData}>
                         <Bar dataKey="weeks" radius={[10, 10, 0, 0]}>
                            {prepCycleData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={index === 2 ? '#3b82f6' : '#e5e5e5'} />
                            ))}
                         </Bar>
                         <XAxis dataKey="stage" axisLine={false} tickLine={false} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <div className="flex justify-between items-baseline mt-2 font-display">
                    <div className="text-neutral-400">4周 → <span className="text-neutral-900 font-bold text-2xl">1周</span></div>
                    <span className="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-xs font-bold uppercase">Efficient</span>
                  </div>
                </div>
             </div>

             {/* Graph 3: Category Table */}
             <div className="bg-white p-6 rounded-2xl shadow-sm border border-neutral-100">
               <div className="flex items-center justify-between mb-6">
                 <p className="text-sm font-bold text-neutral-400 uppercase">类目广告花费占比增长</p>
                 <div className="text-xs bg-neutral-900 text-white px-2 py-1 rounded font-mono">2025-06 vs 2025-12</div>
               </div>
               <div className="space-y-6">
                  {adSpendData.map((item, i) => (
                    <div key={i} className="space-y-2">
                      <div className="flex justify-between text-sm font-bold">
                        <span>{item.category}类目</span>
                        <span>{item.value}% → {item.target}+%</span>
                      </div>
                      <div className="h-3 bg-neutral-100 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          whileInView={{ width: `${item.target}%` }}
                          transition={{ duration: 1.5, delay: i * 0.2 }}
                          className="h-full bg-neutral-900 rounded-full"
                        />
                      </div>
                    </div>
                  ))}
               </div>
             </div>
          </div>
        </div>
      </Page>

      {/* PAGE 7: Cross-department Integration */}
      <Page id="integration" className="snap-start bg-neutral-50 overflow-hidden">
        <SectionTitle title="跨部门整合资源" subtitle="SYNERGY" />
        <p className="text-2xl font-display font-medium text-neutral-500 text-center -mt-12 mb-20">罗马尼亚本对本广告增长</p>
        
        <div className="grid md:grid-cols-3 gap-8">
           {[
             {
               title: "反向指导供给",
               icon: <Radar className="w-10 h-10 text-blue-500" />,
               points: [
                 "告别被动盲招，联合本地团队深挖商品缺口及本本机会点",
                 "输出精准 Target List，化“被动承接”为“主动寻增量”"
               ]
             },
             {
               title: "合作机制设计",
               icon: <ShieldCheck className="w-10 h-10 text-orange-500" />,
               points: [
                 "提炼前端选品 SOP，严控大盘效率",
                 "跟进招品进度"
               ]
             },
             {
               title: "构建数据飞轮",
               icon: <Infinity className="w-10 h-10 text-neutral-900" />,
               tag: "The Growth Flywheel",
               points: [
                 "跳出单纯“流量扶持”的执行思维，建立端到端反馈机制",
                 "前端爆款转化数据 ➡️ 反馈招商极速拓宽相似/衍生品类"
               ]
             }
           ].map((card, i) => (
             <motion.div 
               key={i}
               initial={{ y: 50, opacity: 0 }}
               whileInView={{ y: 0, opacity: 1 }}
               transition={{ delay: i * 0.2 }}
               className="bg-white p-10 rounded-[2.5rem] shadow-xl hover:shadow-2xl transition-shadow duration-500 flex flex-col items-center text-center group"
             >
               <div className="mb-8 group-hover:scale-110 transition-transform duration-500">
                 {card.icon}
               </div>
               {card.tag && (
                 <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest mb-2">{card.tag}</span>
               )}
               <h4 className="text-2xl font-bold mb-8">{card.title}</h4>
               <div className="space-y-4 text-left w-full mt-auto">
                 {card.points.map((point, j) => (
                   <div key={j} className="flex gap-3">
                     <div className="w-1.5 h-1.5 rounded-full bg-neutral-900 mt-2 shrink-0"></div>
                     <p className="text-neutral-600 font-medium leading-relaxed">{point}</p>
                   </div>
                 ))}
               </div>
             </motion.div>
           ))}
        </div>
      </Page>

      {/* PAGE 8: Image Gallery */}
      <Page id="gallery" bgWhite className="snap-start py-0 px-0 sm:px-0 lg:px-0">
        <div className="grid grid-cols-2 md:grid-cols-4 h-screen">
           {[...Array(8)].map((_, i) => (
             <motion.div 
               key={i}
               initial={{ opacity: 0 }}
               whileInView={{ opacity: 1 }}
               transition={{ delay: i * 0.1 }}
               className="relative overflow-hidden group bg-neutral-100"
             >
               <img 
                 src={`https://images.unsplash.com/photo-${[
                   '1551288049-bebda4e38f71',
                   '1505373877841-8d25f7d46678',
                   '1531297484001-80022131f5a1',
                   '1519389950473-47ba0277781c',
                   '1460925895917-afdab827c52f',
                   '1553877522-43269d4ea984',
                   '1522202176988-66273c2fd55f',
                   '1542744173-8e7e53415bb0'
                 ][i]}?q=80&w=800&auto=format&fit=crop`}
                 alt={`Work ${i + 1}`}
                 className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
                 referrerPolicy="no-referrer"
               />
               <div className="absolute inset-0 bg-neutral-900/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                 <p className="text-white font-display font-medium tracking-widest text-sm uppercase">View Case</p>
               </div>
             </motion.div>
           ))}
        </div>
      </Page>

      {/* PAGE 9: Thank You */}
      <Page id="thankyou" className="snap-start bg-neutral-900 text-white flex-col">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          whileInView={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1 }}
          className="text-center"
        >
          <h2 className="text-8xl md:text-[12rem] font-serif italic mb-12 tracking-tighter">Thank you</h2>
          <div className="flex flex-col md:flex-row items-center justify-center gap-12 mt-20">
             <div className="space-y-4">
                <p className="text-neutral-500 uppercase tracking-widest text-sm mb-4">Contact Info</p>
                <p className="text-2xl font-display font-bold">Jialin Portfolio 2025</p>
                <div className="flex items-center justify-center gap-4 text-neutral-400">
                  <Globe className="w-5 h-5" />
                  <span className="font-mono">Overseas Content Strategy</span>
                </div>
             </div>
             <motion.div 
               whileHover={{ scale: 1.05 }}
               className="bg-white text-neutral-900 px-12 py-6 rounded-full font-bold text-xl flex items-center gap-4 cursor-pointer"
             >
               Let's Connect <ArrowRight className="w-6 h-6" />
             </motion.div>
          </div>
        </motion.div>
        
        <div className="absolute bottom-12 text-neutral-700 font-mono text-xs">
          Built with Passion & Precision
        </div>
      </Page>

    </main>
  );
}
