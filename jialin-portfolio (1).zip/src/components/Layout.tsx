import { motion } from "motion/react";
import { ReactNode } from "react";
import { cn } from "@/src/lib/utils";

interface PageProps {
  children: ReactNode;
  className?: string;
  id?: string;
  bgWhite?: boolean;
}

export function Page({ children, className, id, bgWhite = false }: PageProps) {
  return (
    <motion.section
      id={id}
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className={cn(
        "min-h-screen w-full flex flex-col justify-center items-center py-20 px-6 sm:px-12 lg:px-24",
        bgWhite ? "bg-white" : "bg-neutral-50",
        className
      )}
    >
      <div className="max-w-7xl w-full mx-auto">
        {children}
      </div>
    </motion.section>
  );
}

export function SectionTitle({ title, subtitle, centered = true }: { title: string; subtitle?: string; centered?: boolean }) {
  return (
    <div className={cn("mb-16", centered && "text-center")}>
      <motion.p 
        initial={{ opacity: 0, y: 10 }}
        whileInView={{ opacity: 1, y: 0 }}
        className="text-sm font-medium tracking-[0.2em] uppercase text-neutral-400 mb-4"
      >
        {subtitle}
      </motion.p>
      <motion.h2 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="text-4xl md:text-5xl lg:text-6xl font-display font-bold leading-tight"
      >
        {title}
      </motion.h2>
    </div>
  );
}
